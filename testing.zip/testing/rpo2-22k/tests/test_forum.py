# forum/tests.py
import os
from django.test import TestCase
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
from django.utils import timezone
from tabulate import tabulate
from .models import Category, Post, Comment, Like


class TestReport:
    """Утилита для записи и генерации отчёта по тестам."""
    results = []

    @classmethod
    def record(cls, test_name, passed=True, extra="—"):
        status = "✅ PASSED" if passed else "❌ FAILED"
        cls.results.append([test_name, status, extra])

    @classmethod
    def generate_markdown(cls, filename="test_report_forum.md"):
        if not cls.results:
            print("\nНет записанных результатов для отчёта")
            return

        headers = ["Тест", "Статус", "Дополнительно"]
        table = tabulate(cls.results, headers, tablefmt="github")

        total = len(cls.results)
        passed = sum(1 for _, status, _ in cls.results if "PASSED" in status)
        failed = total - passed

        report_content = f"""# Отчёт по тестам моделей форума

**Дата и время:** {timezone.now().strftime("%Y-%m-%d %H:%M:%S")} (+05, Алматы)

**Всего тестов:** {total}  
**Успешно:** {passed}  
**Провалено:** {failed}

{table}

**Примечание:**  
Проваленные тесты также видны в консоли (AssertionError и т.д.).  
Отчёт обновляется после каждого запуска `python manage.py test forum`
"""

        report_path = os.path.join(os.path.dirname(__file__), filename)
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_content)
        print(f"\nОтчёт сохранён → {os.path.abspath(report_path)}")


class ForumModelsTests(TestCase):

    def setUp(self):
        self.user1 = User.objects.create_user(username='user1', password='123')
        self.user2 = User.objects.create_user(username='user2', password='123')

        self.category = Category.objects.create(
            name="Python",
            description="Обсуждение Python"
        )

        self.post = Post.objects.create(
            title="Какой лучший способ изучить Django?",
            content="Ищу рекомендации по курсам и книгам...",
            author=self.user1,
            category=self.category
        )

    # ────────────────────────────────────────
    # Category
    # ────────────────────────────────────────
    def test_category(self):
        with self.subTest("создание объекта"):
            cat = Category.objects.create(name="JavaScript")
            self.assertEqual(cat.name, "JavaScript")
            self.assertTrue(cat.created_at)
            TestReport.record("Category → создание объекта")

        with self.subTest("метод __str__"):
            self.assertEqual(str(self.category), "Python")
            TestReport.record("Category → метод __str__")

    # ────────────────────────────────────────
    # Post
    # ────────────────────────────────────────
    def test_post(self):
        with self.subTest("создание объекта"):
            post = Post.objects.create(
                title="Вопрос по React",
                content="Почему useEffect срабатывает дважды?",
                author=self.user2,
                category=self.category
            )
            self.assertEqual(post.title, "Вопрос по React")
            self.assertEqual(post.author, self.user2)
            self.assertEqual(post.views, 0)
            TestReport.record("Post → создание объекта")

        with self.subTest("метод __str__"):
            self.assertEqual(str(self.post), "Какой лучший способ изучить Django?")
            TestReport.record("Post → метод __str__")

        with self.subTest("related_name 'posts' от категории"):
            self.assertIn(self.post, self.category.posts.all())
            TestReport.record("Post → related_name 'posts' от категории")

        with self.subTest("views по умолчанию 0"):
            self.assertEqual(self.post.views, 0)
            TestReport.record("Post → views по умолчанию 0")

    # ────────────────────────────────────────
    # Comment
    # ────────────────────────────────────────
    def test_comment(self):
        with self.subTest("создание простого комментария"):
            comment = Comment.objects.create(
                post=self.post,
                author=self.user2,
                content="Я рекомендую официальную документацию"
            )
            self.assertEqual(comment.post, self.post)
            self.assertEqual(comment.author, self.user2)
            TestReport.record("Comment → создание простого комментария")

        with self.subTest("вложенный комментарий (replies)"):
            parent = Comment.objects.create(post=self.post, author=self.user1, content="Хороший вопрос!")
            reply = Comment.objects.create(post=self.post, author=self.user2, content="Согласен", parent=parent)
            self.assertIn(reply, parent.replies.all())
            TestReport.record("Comment → вложенный комментарий (replies)")

        with self.subTest("метод __str__"):
            comment = Comment.objects.create(post=self.post, author=self.user2, content="...")
            expected = f"Comment by user2 on {self.post.title}"
            self.assertEqual(str(comment), expected)
            TestReport.record("Comment → метод __str__")

    # ────────────────────────────────────────
    # Like
    # ────────────────────────────────────────
    def test_like(self):
        with self.subTest("лайк поста"):
            like = Like.objects.create(user=self.user2, post=self.post)
            self.assertEqual(like.post, self.post)
            self.assertIsNone(like.comment)
            TestReport.record("Like → лайк поста")

        with self.subTest("лайк комментария"):
            comment = Comment.objects.create(post=self.post, author=self.user1, content="Тест")
            like = Like.objects.create(user=self.user2, comment=comment)
            self.assertEqual(like.comment, comment)
            self.assertIsNone(like.post)
            TestReport.record("Like → лайк комментария")

        with self.subTest("запрет лайкать пост и комментарий одновременно"):
            comment = Comment.objects.create(post=self.post, author=self.user1, content="...")
            like = Like(user=self.user2, post=self.post, comment=comment)
            with self.assertRaises(ValidationError):
                like.full_clean()
            TestReport.record("Like → запрет лайкать пост и комментарий одновременно")

        with self.subTest("уникальность лайка поста на пользователя"):
            Like.objects.create(user=self.user1, post=self.post)
            duplicate = Like(user=self.user1, post=self.post)
            with self.assertRaises(Exception):
                duplicate.save()
            TestReport.record("Like → уникальность лайка поста на пользователя")

        with self.subTest("уникальность лайка комментария на пользователя"):
            comment = Comment.objects.create(post=self.post, author=self.user1, content="...")
            Like.objects.create(user=self.user1, comment=comment)
            duplicate = Like(user=self.user1, comment=comment)
            with self.assertRaises(Exception):
                duplicate.save()
            TestReport.record("Like → уникальность лайка комментария на пользователя")

    # ────────────────────────────────────────
    # Генерация отчёта
    # ────────────────────────────────────────
    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        TestReport.generate_markdown()