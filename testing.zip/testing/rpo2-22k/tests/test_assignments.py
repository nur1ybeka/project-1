# assignments/tests.py
import os
from datetime import timedelta
from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from django.utils import timezone
from tabulate import tabulate
from .models import Assignment, Submission, Comment


class TestReport:
    """Утилита для записи и генерации отчёта по тестам."""
    results = []

    @classmethod
    def record(cls, test_name, passed=True, extra="—"):
        status = "✅ PASSED" if passed else "❌ FAILED"
        cls.results.append([test_name, status, extra])

    @classmethod
    def generate_markdown(cls, filename="test_report_assignments.md"):
        if not cls.results:
            print("\nНет записанных результатов для отчёта")
            return

        headers = ["Тест", "Статус", "Дополнительно"]
        table = tabulate(cls.results, headers, tablefmt="github")

        total = len(cls.results)
        passed = sum(1 for _, status, _ in cls.results if "PASSED" in status)
        failed = total - passed

        report_content = f"""# Отчёт по тестам приложения Assignments

**Дата и время:** {timezone.now().strftime("%Y-%m-%d %H:%M:%S")} (+05, Алматы)

**Всего тестов:** {total}  
**Успешно:** {passed}  
**Провалено:** {failed}

{table}
"""

        report_path = os.path.join(os.path.dirname(__file__), filename)
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(report_content)
        print(f"\nОтчёт сохранён → {os.path.abspath(report_path)}")


class AssignmentsRegressionTests(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.student = User.objects.create_user(username='student', password='123')
        cls.instructor = User.objects.create_user(username='instructor', password='123')

        cls.assignment = Assignment.objects.create(
            title='Тестовое задание по Python',
            description='Написать простую функцию',
            instructions='Реализуйте функцию sum(a, b)',
            max_score=100,
            due_date=timezone.now() + timedelta(days=7),
            is_published=True
        )

    def setUp(self):
        self.client = Client()

    # ────────────────────────────────────────
    # Assignment
    # ────────────────────────────────────────
    def test_assignment_views(self):
        with self.subTest("список заданий возвращает 200"):
            response = self.client.get(reverse('assignments:assignment_list'))
            self.assertEqual(response.status_code, 200)
            TestReport.record("Assignment → список заданий возвращает 200")

        with self.subTest("список содержит название задания"):
            response = self.client.get(reverse('assignments:assignment_list'))
            self.assertContains(response, self.assignment.title)
            TestReport.record("Assignment → список содержит название задания")

        with self.subTest("детальная страница валидного задания"):
            response = self.client.get(reverse('assignments:assignment_detail',
                                               kwargs={'assignment_id': self.assignment.id}))
            self.assertEqual(response.status_code, 200)
            self.assertContains(response, self.assignment.title)
            TestReport.record("Assignment → детальная страница валидного задания")

        with self.subTest("детальная страница несуществующего задания → 404"):
            response = self.client.get(reverse('assignments:assignment_detail',
                                               kwargs={'assignment_id': 999999}))
            self.assertEqual(response.status_code, 404)
            TestReport.record("Assignment → детальная страница несуществующего задания → 404")

    def test_assignment_str(self):
        self.assertEqual(str(self.assignment), 'Тестовое задание по Python')
        TestReport.record("Assignment → метод __str__")

    # ────────────────────────────────────────
    # Submission
    # ────────────────────────────────────────
    def test_submission(self):
        with self.subTest("создание сдачи задания"):
            submission = Submission.objects.create(
                assignment=self.assignment,
                student=self.student,
                content='def sum(a, b): return a + b',
                submitted_at=timezone.now()
            )
            self.assertEqual(submission.assignment, self.assignment)
            self.assertEqual(submission.student, self.student)
            self.assertIsNone(submission.score)
            TestReport.record("Submission → создание сдачи задания")

        with self.subTest("уникальность сдачи"):
            Submission.objects.create(
                assignment=self.assignment,
                student=self.student,
                content='Первая сдача'
            )
            duplicate = Submission(
                assignment=self.assignment,
                student=self.student,
                content='Вторая сдача'
            )
            with self.assertRaises(Exception):
                duplicate.save()
            TestReport.record("Submission → уникальность сдачи (один студент — одно задание)")

        with self.subTest("метод __str__"):
            submission = Submission.objects.create(
                assignment=self.assignment,
                student=self.student,
                content='...'
            )
            expected = f"{self.student.username} - {self.assignment.title}"
            self.assertEqual(str(submission), expected)
            TestReport.record("Submission → метод __str__")

    # ────────────────────────────────────────
    # Comment
    # ────────────────────────────────────────
    def test_comment(self):
        submission = Submission.objects.create(
            assignment=self.assignment,
            student=self.student,
            content='Код'
        )

        with self.subTest("создание комментария"):
            comment = Comment.objects.create(
                submission=submission,
                author=self.instructor,
                content='Хорошее решение, но добавь докстринг',
                is_instructor_comment=True
            )
            self.assertEqual(comment.submission, submission)
            self.assertEqual(comment.author, self.instructor)
            self.assertTrue(comment.is_instructor_comment)
            TestReport.record("Comment → создание комментария к сдаче")

        with self.subTest("метод __str__"):
            comment = Comment.objects.create(
                submission=submission,
                author=self.student,
                content='Готово'
            )
            expected = f"Comment by {self.student.username} on {submission}"
            self.assertEqual(str(comment), expected)
            TestReport.record("Comment → метод __str__")

    # ────────────────────────────────────────
    # Генерация отчёта
    # ────────────────────────────────────────
    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        TestReport.generate_markdown()